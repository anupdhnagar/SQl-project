use bankdata ;

 /*2.Identify the top 5 customers with the highest Estimated Salary in the last quarter of the year. (SQL)
*/ 
 select CustomerId,EstimatedSalary,quarter(BankDOJ) from customerinfo
 order by EstimatedSalary desc
 limit 5;
 
 /*3.Calculate the average number of products used by customers who have a credit card. (SQL)*/
 
 select CustomerId,avg(NumOfProducts) from bank_churn
 where Has_creditcard =1
 group by CustomerId;
 
 /*5.Compare the average credit score of customers who have exited and those who remain. (SQL)*/

 Select CustomerId, avg(CreditScore) from bank_churn
 where Exited =1 or Exited=0
  group by CustomerId;
 
 /*6.Which gender has a higher average estimated salary, and how does it relate to the number
 of active accounts? (SQL)
*/

 select b.IsActiveMember,g.GenderID,avg(c.EstimatedSalary)avg_salary from customerinfo c
 join bank_churn b on b.CustomerId=b.CustomerId
 join gender g on g.GenderID=c.GenderID
 group by IsActiveMember,GenderID
 order by avg_salary desc;
 

 /*7.Segment the customers based on their credit score and identify the segment with the highest exit rate. (SQL)
*/

select CustomerId, CreditScore  from bank_churn
where Exited =1
order by CreditScore desc;


/*8.Find out which geographic region has the highest number of active customers with a tenure greater than 5 years. (SQL)
*/

select max(CustomerId) as max_activecustomer from bank_churn
where IsActiveMember =1 and Tenure>5;


/*11.Examine the trend of customers joining over time and identify any seasonal patterns (yearly or monthly). Prepare the data through SQL and then visualize it.
*/

select extract(year from BankDOJ) as years,
extract(month from BankDOJ) as months ,
count(CustomerId) from
 customerinfo
 group by years
 order by months;


/*15.Using SQL, write a query to find out the gender-wise average income of males and females in each geography id. Also, rank the gender according to the average value. (SQL)
*/

select GenderID,GeographyID,EstimatedSalary,
dense_rank() over (partition by GenderID order by EstimatedSalary) as ranks
from customerinfo;


/*16.Using SQL, write a query to find out the average tenure of the people who have exited in each age bracket (18-30, 30-50, 50+).*/
SELECT 
    CASE
        WHEN Age BETWEEN 18 AND 30 THEN '18-30'
        WHEN Age BETWEEN 31 AND 50 THEN '30-50'
        ELSE '50+'
    END AS age_bracket,
    AVG(b.Tenure) AS average_tenure
FROM 
    customerinfo c join bank_churn b on c.CustomerId = b.CustomerId
    where Exited =1
GROUP BY 
    CASE
        WHEN Age BETWEEN 18 AND 30 THEN '18-30'
        WHEN Age BETWEEN 31 AND 50 THEN '30-50'
        ELSE '50+'
    END;




/*19. Rank each bucket of credit score as per the number of customers who have churned the bank.
*/
select CustomerId,CreditScore,
rank() over ( order by CreditScore) as Rnked
 from bank_churn
order by CreditScore asc;


/* 20.According to the age buckets find the number of customers who have a credit card. Also retrieve those buckets that have lesser than average number of credit cards per bucket.
*/

SELECT 
    CASE
        WHEN Age BETWEEN 18 AND 30 THEN '18-30'
        WHEN Age BETWEEN 31 AND 50 THEN '30-50'
        ELSE '50+'
    END AS age_bracket,
    count(b.CustomerId) AS numofcustomer
FROM 
    customerinfo c join bank_churn b on c.CustomerId = b.CustomerId
    where Has_creditcard =1
GROUP BY 
    CASE
        WHEN Age BETWEEN 18 AND 30 THEN '18-30'
        WHEN Age BETWEEN 31 AND 50 THEN '30-50'
        ELSE '50+'
    END;
    
/*21 Rank the Locations as per the number of people who have churned the bank and average balance of the customers.
*/

select count(CustomerId) as numofpeople,avg(Balance),
rank() over(order by avg(Balance) desc) as ranks
 from bank_churn
group by CustomerId;

/*22.As we can see that the “CustomerInfo” table has the CustomerID and Surname, now if we have to join it with a table where the primary key is also a combination of CustomerID and Surname, come up with a column where the format is “CustomerID_Surname”.*/

select c.CustomerId,c.Surname from customerinfo c
join 
 customerinfo c1 on
 c.CustomerId= c1.CustomerId;
 
 
 /*23.	Without using “Join”, can we get the “ExitCategory” from ExitCustomers 
table to Bank_Churn table? If yes do this using SQL.*/

UPDATE bank_churn
SET ExitCategory = (
    SELECT ExitCategory
    FROM exitcustomer
    WHERE exitcustomer.CustomerId = bank_churn.CustomerId
);

 
 /* 25.Write the query to get the customer IDs, their last name, and whether they are active or not for the customers whose surname ends with “on”.*/

select CustomerId,Surname as last_name from  customerinfo
where Surname  like '%on';
 
/*Subjective 10.Utilize SQL queries to segment customers based on demographics and account details*/
select b.CustomerId ,b.CreditScore ,b.Tenure,c.age ,c.GenderID 
from bank_churn b 
join 
customerinfo c on b.CustomerId =c.CustomerId;

/* subjective 14 .In the “Bank_Churn” table how can you modify the name of the “HasCrCard” column to “Has_creditcard”?*/

alter table bank_churn
rename column HasCrCard to Has_creditcard;

